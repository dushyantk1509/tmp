@outputSchema("chararray")
def capitalize(inp):
    return inp.upper()
